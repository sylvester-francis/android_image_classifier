package com.robertlevonyan.demo.camerax.enums

enum class CameraRatio {
    RATIO_1_1,
    RATIO_4_3,
    RATIO_SCALE
}