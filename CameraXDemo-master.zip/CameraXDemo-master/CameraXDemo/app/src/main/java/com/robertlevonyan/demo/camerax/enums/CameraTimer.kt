package com.robertlevonyan.demo.camerax.enums

enum class CameraTimer {
    OFF, S3, S10
}